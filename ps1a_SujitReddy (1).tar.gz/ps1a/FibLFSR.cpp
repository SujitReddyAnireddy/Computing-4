#include "FibLFSR.h"
#include <string>
#include <math.h>

std::ostream& operator<< (std::ostream& return_value, const FibLFSR& fibLFSR) {
    return_value << fibLFSR.reg;
    return return_value;
}

int FibLFSR::getBit(char a) {
    if (a == '1') return 1;
    else if (a == '0') return 0;
    else return -1;
}

FibLFSR::FibLFSR(std::string seed){
    reg = seed;
}


int FibLFSR::step() {

    std::string reg_copy = reg.substr(1);
  int resulting_bit = (((reg[0] != reg[2]) != getBit(reg[3])) != getBit(reg[5]));

    FibLFSR::reg = reg_copy;
    FibLFSR::reg += std::to_string(resulting_bit);
    return resulting_bit;
}

int FibLFSR::generate(int k) {
    int r = 0;
    for(int i = 0; i < k; i++){
        int x = step();
        std::cout << reg << " " << x << std::endl;
        r = (r * 2) + x;
    }
    return r;
}