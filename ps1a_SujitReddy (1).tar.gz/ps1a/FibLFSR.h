/*
*  Computing IV - Ps1a
*  Instructor: Prof. Yelena Rykalova
*
*  Due Date: 20th September 2021
*
*  Author : Anireddy Sujit Reddy (UML ID 01987338)
*
*  Description: In this program the implementation of a Fibonacci Linear Feedback Shift Register(LFSR)
                is used.
*/
#include <iostream>

class FibLFSR {
    public:
        FibLFSR(std::string seed);
        int step();
        int generate(int k);
        friend std::ostream& operator<< (std::ostream& out, const FibLFSR& fibLFSR);
    private:
        std::string reg;
        int getBit(char a);

};