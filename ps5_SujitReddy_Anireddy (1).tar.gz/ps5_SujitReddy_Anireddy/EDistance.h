#ifndef EDistance_H
#define EDistance_H
#include <string>

class EDistance
{
private:
    int **opt;
    std::string x;
    std::string y;
    int M, N;

public:
    EDistance(const std::string &a, const std::string &b);
    ~EDistance();
    static int penalty(char a, char b);
    static int min(int a, int b, int c);
    int OptDistance();
    std::string Alignment();
};
#endif