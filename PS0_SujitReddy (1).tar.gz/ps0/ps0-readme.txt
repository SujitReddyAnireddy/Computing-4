/**********************************************************************
 *  ps0-readme template                                                   
 *  Hello World Assignment                       
 **********************************************************************/

Your name: Anireddy Sujit Reddy

Operating system you're using (Linux, OS X, or Windows): Windows, Virtual Machine Linux

IDE or text editor you're using: Text Editor

Hours to complete assignment: 5 Hours

/**********************************************************************
 *  Part of Assignment 0 is to read the collaboration policy in syllabus.
 *  
 *  If you haven't done this, please do so now.
 *
 *  Read the University policy Academic Integrity,
 *  and answer the following question:
 *
 * There are six examples of academic misconduct, labeled (a) through
 * (f). Other than (a), "Seeks to claim credit for the work or efforts
 * of another without authorization or citation," which of these do you
 * think would most apply to this class, and why? Write approx. 100-200
 * words.
 *
 * Note: there is no single correct answer to this. I am looking for
 * your opinion.
 **********************************************************************/
 
 - I feel like (f) "Asssists other students in any of the above acts" 
  Apply's to this class as all of the points given are valid reasons of academic
  integrity. Guiding someone and completely helping them out are two completely 
  different things and students should know the limit of help they need to provide 
  to there classmates. 
  If the student who is getting the help isn't understading the concepts and is
  completely depending on his/her friends or someone else, failed 
  the academic integrity rules.
  
/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
- Took some guidance from my classmate on how to add colour mode in my program.
  **********************************************************************/


/**********************************************************************
 *  Describe any serious problems you encountered.                    
-  Nothing as for now.
 **********************************************************************/
 


/**********************************************************************
 *  List any other comments here.
 - No comments as for now.                                     
 **********************************************************************/






