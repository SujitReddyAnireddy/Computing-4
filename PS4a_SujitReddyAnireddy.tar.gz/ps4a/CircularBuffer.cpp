/*
 * Copyright 2021 Anireddy Sujit Reddy(01987338)
 * All rights reserved.
 * MIT Licensed - see http://opensource.org/licenses/MIT for details.
 */
#include "CircularBuffer.h"

CircularBuffer::CircularBuffer(int c) {
    if (c < 1) {
        throw
            std::invalid_argument\
            ("CircularBuffer constructor: Max_size > 0");
    }

    Max_size = c;
    buffer.resize(Max_size);

    head = 0;
    tail = 0;
    len = 0;
}

int CircularBuffer::size() {
    return len;
}

bool CircularBuffer::isEmpty() {
    auto lamda= [](int len) 
    {
        return len == 0;
    };
    return lamda(len);
}

bool CircularBuffer::isFull() {
    return (len == Max_size) ? true : false;
}

void CircularBuffer::enqueue(int16_t x) {
  if (isFull()) {
    throw
      std::runtime_error("enqueue: can't enqueue to a full ring");
  }

  if (tail >= Max_size) {
    tail = 0;
  }

  buffer.at(tail) = x;

  tail++;
  len++;
}

int16_t CircularBuffer::dequeue() {
  if (isEmpty()) {
    throw
      std::runtime_error("dequeue: can't dequeue an empty ring");
  }

  int16_t first = buffer.at(head);
  buffer.at(head) = 0;

  head++;
  len--;

  if (head >= Max_size) {
    head = 0;
  }

  return first;
}

int16_t CircularBuffer::peek() {
  if (isEmpty()) {
    throw
      std::runtime_error("cant peek");
  }
  return buffer.at(head);
}

void CircularBuffer::prettyPrint() {
  std::cout << "Buffer: Max_size " << Max_size << " ";
  std::cout << ", tail " << tail;
  std::cout << ", head " << Max_size;
  std::cout << ", current length " << len << "\n";
  std::cout << "Buffer: ";

  int f = 0;
  int back = head;

  while (f < len) {
    if (back >= Max_size) {
      back = 0;
    }

    std::cout << buffer[back] << " ";
    back++;
    f++;
  }
  std::cout << std::endl;
}





