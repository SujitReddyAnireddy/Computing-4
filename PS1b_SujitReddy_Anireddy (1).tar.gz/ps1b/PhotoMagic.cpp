

/*
Name: Anireddy Sujit Reddy
Instructor: Prof. Yelena Rykalova
Linear Feedback Shift Register (part B)                                                                   
Computing IV - Assignment - PS1b
*/
#include <iostream>
#include <string>
#include <sstream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "FibLFSR.h"
std::string password(std::string st){
	
	int convert = 53;
	int len = st.length();
	for(int i = 0; i < len; i++){
		convert = convert ^ st[i];
		convert *= convert;
	}

	std::string binary;
    while(convert != 0) {
		binary = (convert % 2 == 0 ? "0" : "1") + binary; 
		convert /= 2;
	}

	return binary;
}

void transform( sf::Image& img, FibLFSR* bit_generator) {
  sf::Vector2u imgsize = img.getSize();
  sf::Color p;
  for(int x = 0; x < (signed)imgsize.x; x++)
  {
    for(int y = 0; y < (signed)imgsize.y; y++)
    {
      p = img.getPixel(x, y);
      p.r = p.r ^ bit_generator -> generate(8);
      p.g = p.g ^ bit_generator -> generate(8);
      p.b = p.b ^ bit_generator -> generate(8);
      img.setPixel(x, y, p);
    }
  }
}

int main(int argc, char* argv[]){
  if(argc != 4){
    std::cout << "Bad Input, Usage: ./PhotoMagic <inputfilename> <outputfilename> <seed>\n";
    return -1;
  }
  std::string input_fname(argv[1]);
  std::string output_fname(argv[2]);
  std::string givenpassword(argv[3]);

  std::string seed = password(givenpassword);
   
  FibLFSR bit_generator(seed);
  sf::Image input_image;
  if (!input_image.loadFromFile(input_fname))
  {
    return -1;
  }

  sf::Image output_image;
  if (!output_image.loadFromFile(input_fname))
  {
    return -1;
  }
  sf::Vector2u imgsize = input_image.getSize();
  sf::RenderWindow input_window(sf::VideoMode(imgsize.x, imgsize.y), "Input Image");
  sf::RenderWindow output_window(sf::VideoMode(imgsize.x, imgsize.y), "Output Image");
  sf::Texture in_texture, out_texture;
  in_texture.loadFromImage(input_image);

  transform(input_image, &bit_generator);

  out_texture.loadFromImage(input_image);
  sf::Sprite in_sprite, out_sprite;
  in_sprite.setTexture(in_texture);
  out_sprite.setTexture(out_texture);
  while (input_window.isOpen() && output_window.isOpen())
  {
    sf::Event event;

    while (input_window.pollEvent(event))
    {
      if (event.type == sf::Event::Closed)
      {
        input_window.close();
      }
    }

    while (output_window.pollEvent(event))
    {
      if (event.type == sf::Event::Closed)
      {
        output_window.close();
      }
    }

    input_window.clear();
    input_window.draw(in_sprite);    
    input_window.display();

    output_window.clear();
    output_window.draw(out_sprite);    
    output_window.display();
  }
  if (!input_image.saveToFile(output_fname))
  {
    return -1;
  }

  return 0;
}
