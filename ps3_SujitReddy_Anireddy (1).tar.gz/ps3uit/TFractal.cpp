#include "Triangle.h"
#include <vector>
#include <iostream>
#include <random>

#define height_of_screen 750
#define width_of_screen 750
#define DEF 0.867

void fTree(Triangle triangle, int depth, int length, sf::RenderWindow *window) {
    if(depth <= 0)
        return;
    
    std::cout << "calculating - depth: " << depth << std::endl;

    triangle.bottom = new Triangle(sf::Vector2f(triangle.p3.x - length, triangle.p3.y), triangle.p3, sf::Vector2f(triangle.p3.x - length/2, triangle.p3.y + (length * DEF)));
    triangle.left = new Triangle(sf::Vector2f(triangle.p1.x - length/2, triangle.p1.y - length), sf::Vector2f(triangle.p1.x + length/2, triangle.p1.y - length), triangle.p1);
    triangle.right = new Triangle(triangle.p2, sf::Vector2f(triangle.p2.x + length, triangle.p2.y), sf::Vector2f(triangle.p2.x + length/2, triangle.p2.y + length));

    window -> draw(*triangle.bottom);
    window -> draw(*triangle.left);
    window -> draw(*triangle.right);

    depth--;

    fTree(*triangle.left, depth, length/2, window);
    fTree(*triangle.right, depth, length/2, window);
    fTree(*triangle.bottom, depth, length/2, window);
}

    int main(int argc, char* argv[]) {

    if (argc!= 3) {
        std::cout << "[length] [depth]\n";
        return -1;
    }

    sf::RenderWindow window(sf::VideoMode(width_of_screen, height_of_screen), "PS3 Serpinski");
    window.setFramerateLimit(60);

    int length = atoi(argv[1]);
    int depth = atoi(argv[2]);

    float x = width_of_screen/2 - length/2;
    float y = height_of_screen/2 - length/2;


    Triangle initialTriangle(sf::Vector2f(x, y), sf::Vector2f(x + length, y), sf::Vector2f(x + length/2, y + (length * DEF)));

    window.draw(initialTriangle);
    fTree(initialTriangle, depth, length/2, &window);

    
    while (window.isOpen()){

        sf::Event event;
        while (window.pollEvent(event)){
            if (event.type == sf::Event::Closed)
                window.close();
        }
        
        window.display();
    }
}
