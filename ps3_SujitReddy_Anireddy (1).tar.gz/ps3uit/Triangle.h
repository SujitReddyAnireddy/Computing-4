#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

class Triangle: public sf::Drawable {
    public:
    Triangle(sf::Vector2f, sf::Vector2f, sf::Vector2f);
    sf::Vector2f p1, p2, p3;
    Triangle *left, *right, *bottom;
    int length;
    
    private:
    void draw (sf::RenderTarget &target, sf::RenderStates states) const;
};