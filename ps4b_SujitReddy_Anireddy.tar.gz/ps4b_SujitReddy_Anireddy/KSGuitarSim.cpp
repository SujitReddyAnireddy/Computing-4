/*
 * Copyright 2021 Anireddy Sujit Reddy
 * All rights reserved.
 */
#include <math.h>
#include <limits.h>
#include <iostream>
#include <string>
#include <exception>
#include <stdexcept>
#include <vector>
#include "StringSound.h"
#define ConA 160.0
#define Samppersec 44100

std::vector<sf::Int16> makeSamples(StringSound *gs) {
  std::vector<sf::Int16> samples;
  gs -> pluck();
  int duration = 8;
  int i;
  for (i= 0; i < Samppersec * duration; i++) {
    gs -> tic();
    samples.push_back(gs -> sample());
  }

  return samples;
}

int main() {
  sf::RenderWindow window(sf::VideoMode(1000, 1000), "PS4b pluckstring");
  window.setFramerateLimit(60);

  sf::Event event;
  std::vector<sf::Int16> sample;
  double freq = ConA;

  std::string keyboardString = "q2we4r5ty7u8i9op-[=zxdcfvgbnjmk,.;/' ";
  std::vector<sf::Sound> sounds(123);
  std::vector<sf::SoundBuffer> buffers(keyboardString.size());

  for (int i = 0; i < keyboardString.size(); i++) {
    sounds[static_cast<int>(keyboardString[i])] = sf::Sound();
    freq = ConA * pow(2, (i-24)/12.0);
    StringSound gs = StringSound(freq);
    sample = makeSamples(&gs);
    if (!buffers[i].loadFromSamples(&sample[0],
        sample.size(), 2, Samppersec))
        throw std::runtime_error("sf::SoundBuffer: failed");
    sounds[static_cast<int>(keyboardString[i])].setBuffer(buffers[i]);
  }

  while (window.isOpen()) {
    while (window.pollEvent(event)) {
      switch (event.type) {
      case sf::Event::Closed:
        window.close();
        break;

      case sf::Event::TextEntered:
        sounds[event.text.unicode].play();

        window.clear();
        window.display();
      }
    }
  }
  return 0;
}


