/**********************************************************************
 *  N-Body Simulation ps2b-readme.txt template
 **********************************************************************/

 Name: Anireddy Sujit Reddy / UML ID - 01987338
 Email - SujitReddy_Anireddy@student.uml.edu

 Hours to complete assignment: Roughly 4 hours 

/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
 The assignment was to simulate movement of celestial bodies in 2D plane.
 I learned how to use smart pointers and it was a very helpful feature 
 within the programming language, it was overall a fun assignment to do.

/**********************************************************************
 *  If you created your own universe for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/
 No I did not make any extras in the universe but added background music 
 and background image. 

/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
 I did not receive any help except from the pdf and the explanation in
 the class.

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
 The implementation of smart pointers was tricky but eventually understood
 the concept and implemented it in the code. 

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
 Background image and music is added. 